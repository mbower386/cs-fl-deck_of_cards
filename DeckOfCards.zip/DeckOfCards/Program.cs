﻿using System;
using DeckOfCards.DeckClass;

namespace DeckOfCards
{
    class Program
    {
        static void Main (string[] args)
        {
            
        }
    }
}